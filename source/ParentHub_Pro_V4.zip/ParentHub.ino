#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <time.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <esp_wifi.h>
extern "C" {
  #include "lwip/etharp.h"
  #include "lwip/netif.h"
  #include "lwip/ip4_addr.h"
}

// ============================================================
// Parent Hub V4.0 Pro - ESP32 DevKit V1
// - Saved Wi-Fi is always the primary connection
// - Wi-Fi can be changed anytime at /wifi; captive setup is fallback
// - LAN ARP discovery for IPv4 /24 networks
// - Device registry + groups + daily limits + time windows
// - Android Box agent heartbeat/policy endpoints
// - Responsive local web app
// ============================================================

WebServer server(80);
DNSServer dnsServer;
Preferences prefs;
WiFiUDP arpUdp;

static const char* AP_SSID = "ParentHub-Setup";
static const char* AP_PASS = "parenthub"; // 8 chars
static const char* HOSTNAME = "parenthub";
static const char* FW_VERSION = "4.0.0";
static const char* UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/ledinhtien219/quanlyinternet/main/update.json";
static const char* RELEASES_URL = "https://github.com/ledinhtien219/quanlyinternet/releases/latest";

bool setupMode = false;
bool scanRunning = false;
unsigned long lastAutoScan = 0;
unsigned long lastMinuteTick = 0;
unsigned long lastUsageSave = 0;
String lastDayKey = "";

struct Device {
  String id;
  String name;
  String group;
  String kind;
  String ip;
  String mac;
  bool manualBlocked = false;
  bool online = false;
  bool agentSeen = false;
  bool agentActive = false;
  unsigned long lastSeenMs = 0;
  unsigned long lastAgentMs = 0;
  int limitMin = 120;
  int bonusMin = 0;
  int usedMin = 0;
  String from = "06:30";
  String to = "20:30";
  // Monitoring/session fields. For Android Box these are driven by the Agent;
  // for iPad/other clients they are an approximation based on LAN presence.
  bool activeNow = false;
  int currentSessionMin = 0;
  int longestSessionMin = 0;
  int sessionsToday = 0;
  String currentApp = "";
  String currentPackage = "";
  int histMin[7] = {0,0,0,0,0,0,0};
  String histDay[7];
};

struct AppUsage {
  String deviceId;
  String packageName;
  String label;
  int minutes = 0;
};

AppUsage appUsage[32];
int appUsageCount = 0;

struct FoundDevice {
  String ip;
  String mac;
  String hostname;
  String nameSource;
  unsigned long seenMs = 0;
};

Device devices[32];
int deviceCount = 0;
FoundDevice found[48];
int foundCount = 0;

// -------------------- Utility --------------------
String jsonEscape(const String &s) {
  String o;
  o.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '"' || c == '\\') { o += '\\'; o += c; }
    else if (c == '\n') o += "\\n";
    else if (c == '\r') o += "\\r";
    else o += c;
  }
  return o;
}

String normalizeMac(String s) {
  s.toLowerCase();
  s.replace("-", ":");
  return s;
}

String makeId(String mac, String ip) {
  String s = mac.length() ? mac : ip;
  s.replace(":", "");
  s.replace(".", "");
  s.replace(" ", "");
  if (!s.length()) s = String((uint32_t)esp_random(), HEX);
  return s;
}

int findDeviceById(const String &id) {
  for (int i = 0; i < deviceCount; i++) if (devices[i].id == id) return i;
  return -1;
}

int findDeviceByMac(const String &mac) {
  String m = normalizeMac(mac);
  if (!m.length()) return -1;
  for (int i = 0; i < deviceCount; i++) if (normalizeMac(devices[i].mac) == m) return i;
  return -1;
}

int findDeviceByIp(const String &ip) {
  for (int i = 0; i < deviceCount; i++) if (devices[i].ip == ip) return i;
  return -1;
}

int hhmmToMin(const String &s) {
  int p = s.indexOf(':');
  if (p < 0) return 0;
  int h = s.substring(0, p).toInt();
  int m = s.substring(p + 1).toInt();
  return constrain(h * 60 + m, 0, 1439);
}

bool timeKnown() {
  time_t now = time(nullptr);
  return now > 1700000000;
}

int nowMinuteOfDay() {
  if (!timeKnown()) return -1;
  time_t now = time(nullptr);
  struct tm t;
  localtime_r(&now, &t);
  return t.tm_hour * 60 + t.tm_min;
}

String currentDayKey() {
  if (!timeKnown()) return "";
  time_t now = time(nullptr);
  struct tm t;
  localtime_r(&now, &t);
  char b[12];
  snprintf(b, sizeof(b), "%04d%02d%02d", t.tm_year + 1900, t.tm_mon + 1, t.tm_mday);
  return String(b);
}

bool insideWindow(const Device &d) {
  int n = nowMinuteOfDay();
  if (n < 0) return true; // NTP not ready: don't false-lock
  int a = hhmmToMin(d.from), b = hhmmToMin(d.to);
  if (a == b) return true;
  if (a < b) return n >= a && n < b;
  return n >= a || n < b; // crosses midnight
}

bool effectiveLocked(const Device &d) {
  if (d.manualBlocked) return true;
  if (!insideWindow(d)) return true;
  int allowed = d.limitMin + d.bonusMin;
  if (allowed > 0 && d.usedMin >= allowed) return true;
  return false;
}

int remainingMin(const Device &d) {
  int allowed = d.limitMin + d.bonusMin;
  if (allowed <= 0) return 9999;
  return max(0, allowed - d.usedMin);
}

String groupLabel(const String &g) {
  if (g == "Be") return "Bé";
  if (g == "BoMe") return "Bố mẹ";
  if (g == "Khach") return "Khách";
  if (g == "IoT") return "IoT";
  return g;
}

// -------------------- Persistence --------------------
void seedDeviceIfEmpty() {
  if (deviceCount) return;
  Device &d = devices[0];
  d.id = "b859ce7eedbe";
  d.name = "ViettelTV 4K Box";
  d.group = "Be";
  d.kind = "AndroidBox";
  d.ip = "192.168.1.14";
  d.mac = "b8:59:ce:7e:ed:be";
  d.limitMin = 120;
  d.from = "06:30";
  d.to = "20:30";
  deviceCount = 1;
}

void saveDevices() {
  DynamicJsonDocument doc(24576);
  JsonArray a = doc.to<JsonArray>();
  for (int i = 0; i < deviceCount; i++) {
    Device &d = devices[i];
    JsonObject o = a.add<JsonObject>();
    o["id"] = d.id; o["name"] = d.name; o["group"] = d.group; o["kind"] = d.kind;
    o["ip"] = d.ip; o["mac"] = d.mac; o["manualBlocked"] = d.manualBlocked;
    o["limitMin"] = d.limitMin; o["bonusMin"] = d.bonusMin; o["usedMin"] = d.usedMin;
    o["from"] = d.from; o["to"] = d.to;
    o["longestSessionMin"] = d.longestSessionMin; o["sessionsToday"] = d.sessionsToday;
    JsonArray hm = o.createNestedArray("histMin");
    JsonArray hd = o.createNestedArray("histDay");
    for (int h = 0; h < 7; h++) { hm.add(d.histMin[h]); hd.add(d.histDay[h]); }
  }
  String s; serializeJson(doc, s);
  prefs.putString("devices", s);
  if (lastDayKey.length()) prefs.putString("daykey", lastDayKey);

  DynamicJsonDocument adoc(8192);
  JsonArray aa = adoc.to<JsonArray>();
  for (int i = 0; i < appUsageCount; i++) {
    JsonObject a = aa.add<JsonObject>();
    a["deviceId"] = appUsage[i].deviceId; a["package"] = appUsage[i].packageName;
    a["label"] = appUsage[i].label; a["minutes"] = appUsage[i].minutes;
  }
  String as; serializeJson(adoc, as); prefs.putString("appUsage", as);
}

void loadDevices() {
  String s = prefs.getString("devices", "");
  lastDayKey = prefs.getString("daykey", "");
  if (!s.length()) { seedDeviceIfEmpty(); saveDevices(); return; }
  DynamicJsonDocument doc(24576);
  if (deserializeJson(doc, s)) { seedDeviceIfEmpty(); return; }
  deviceCount = 0;
  for (JsonObject o : doc.as<JsonArray>()) {
    if (deviceCount >= 32) break;
    Device &d = devices[deviceCount++];
    d.id = String((const char*)(o["id"] | ""));
    d.name = String((const char*)(o["name"] | "Thiết bị"));
    d.group = String((const char*)(o["group"] | "Khach"));
    d.kind = String((const char*)(o["kind"] | "Other"));
    d.ip = String((const char*)(o["ip"] | ""));
    d.mac = normalizeMac(String((const char*)(o["mac"] | "")));
    d.manualBlocked = o["manualBlocked"] | false;
    d.limitMin = o["limitMin"] | 120;
    d.bonusMin = o["bonusMin"] | 0;
    d.usedMin = o["usedMin"] | 0;
    d.from = String((const char*)(o["from"] | "06:30"));
    d.to = String((const char*)(o["to"] | "20:30"));
    d.longestSessionMin = o["longestSessionMin"] | 0;
    d.sessionsToday = o["sessionsToday"] | 0;
    JsonArray hm = o["histMin"].as<JsonArray>();
    JsonArray hd = o["histDay"].as<JsonArray>();
    for (int h = 0; h < 7; h++) {
      d.histMin[h] = (hm && h < (int)hm.size()) ? (hm[h] | 0) : 0;
      d.histDay[h] = (hd && h < (int)hd.size()) ? String((const char*)(hd[h] | "")) : "";
    }
  }
  seedDeviceIfEmpty();

  appUsageCount = 0;
  String as = prefs.getString("appUsage", "");
  if (as.length()) {
    DynamicJsonDocument adoc(8192);
    if (!deserializeJson(adoc, as)) {
      for (JsonObject a : adoc.as<JsonArray>()) {
        if (appUsageCount >= 32) break;
        AppUsage &u = appUsage[appUsageCount++];
        u.deviceId = String((const char*)(a["deviceId"] | ""));
        u.packageName = String((const char*)(a["package"] | ""));
        u.label = String((const char*)(a["label"] | ""));
        u.minutes = a["minutes"] | 0;
      }
    }
  }
}

// -------------------- LAN discovery --------------------
String macToString(const struct eth_addr *e) {
  if (!e) return "";
  char b[18];
  snprintf(b, sizeof(b), "%02x:%02x:%02x:%02x:%02x:%02x",
    e->addr[0], e->addr[1], e->addr[2], e->addr[3], e->addr[4], e->addr[5]);
  return String(b);
}


String cleanDeviceHostname(String h) {
  h.trim();
  if (h.endsWith(".")) h.remove(h.length() - 1);
  if (h.endsWith(".local")) h.remove(h.length() - 6);
  h.trim();
  return h;
}

int skipDnsName(const uint8_t *buf, int len, int pos) {
  int guard = 0;
  while (pos < len && guard++ < 128) {
    uint8_t n = buf[pos];
    if (n == 0) return pos + 1;
    if ((n & 0xC0) == 0xC0) return (pos + 1 < len) ? pos + 2 : len;
    if (n > 63 || pos + 1 + n > len) return len;
    pos += 1 + n;
  }
  return len;
}

String decodeDnsName(const uint8_t *buf, int len, int pos, int depth = 0) {
  if (depth > 8 || pos < 0 || pos >= len) return "";
  String out;
  int guard = 0;
  while (pos < len && guard++ < 128) {
    uint8_t n = buf[pos++];
    if (n == 0) break;
    if ((n & 0xC0) == 0xC0) {
      if (pos >= len) break;
      int ptr = ((n & 0x3F) << 8) | buf[pos++];
      String tail = decodeDnsName(buf, len, ptr, depth + 1);
      if (tail.length()) { if (out.length()) out += "."; out += tail; }
      break;
    }
    if (n > 63 || pos + n > len) break;
    if (out.length()) out += ".";
    for (int i = 0; i < n; i++) {
      char c = (char)buf[pos++];
      if (c >= 32 && c <= 126) out += c;
    }
  }
  return out;
}

int appendDnsName(uint8_t *buf, int maxLen, int pos, const String &name) {
  int start = 0;
  while (start < (int)name.length()) {
    int dot = name.indexOf('.', start);
    if (dot < 0) dot = name.length();
    int n = dot - start;
    if (n <= 0 || n > 63 || pos + 1 + n >= maxLen) return -1;
    buf[pos++] = (uint8_t)n;
    for (int i = 0; i < n; i++) buf[pos++] = (uint8_t)name[start + i];
    start = dot + 1;
  }
  if (pos >= maxLen) return -1;
  buf[pos++] = 0;
  return pos;
}

String resolveMdnsReverse(const IPAddress &ip) {
  WiFiUDP u;
  uint16_t port = 53000 + (esp_random() % 1000);
  if (!u.begin(port)) return "";

  String q = String(ip[3]) + "." + String(ip[2]) + "." + String(ip[1]) + "." + String(ip[0]) + ".in-addr.arpa";
  uint8_t pkt[180] = {0};
  // mDNS header: ID=0, flags=0, QDCOUNT=1
  pkt[5] = 1;
  int pos = appendDnsName(pkt, sizeof(pkt), 12, q);
  if (pos < 0 || pos + 4 > (int)sizeof(pkt)) { u.stop(); return ""; }
  pkt[pos++] = 0; pkt[pos++] = 12;       // PTR
  pkt[pos++] = 0x80; pkt[pos++] = 0x01; // IN + unicast response requested

  IPAddress mdns(224, 0, 0, 251);
  u.beginPacket(mdns, 5353); u.write(pkt, pos); u.endPacket();

  unsigned long deadline = millis() + 140;
  uint8_t resp[768];
  while ((long)(deadline - millis()) > 0) {
    int n = u.parsePacket();
    if (n > 0) {
      n = min(n, (int)sizeof(resp));
      int got = u.read(resp, n);
      if (got >= 12) {
        int qd = (resp[4] << 8) | resp[5];
        int an = (resp[6] << 8) | resp[7];
        int p = 12;
        for (int i = 0; i < qd && p < got; i++) { p = skipDnsName(resp, got, p); p += 4; }
        for (int i = 0; i < an && p + 10 <= got; i++) {
          String rrName = decodeDnsName(resp, got, p);
          p = skipDnsName(resp, got, p);
          if (p + 10 > got) break;
          uint16_t type = (resp[p] << 8) | resp[p+1];
          uint16_t rdlen = (resp[p+8] << 8) | resp[p+9];
          p += 10;
          if (p + rdlen > got) break;
          if (type == 12 && (rrName.equalsIgnoreCase(q) || rrName.endsWith("in-addr.arpa"))) {
            String host = cleanDeviceHostname(decodeDnsName(resp, got, p));
            if (host.length()) { u.stop(); return host; }
          }
          p += rdlen;
        }
      }
    }
    delay(4);
  }
  u.stop();
  return "";
}

String resolveNetbiosName(const IPAddress &ip) {
  WiFiUDP u;
  uint16_t port = 54000 + (esp_random() % 1000);
  if (!u.begin(port)) return "";
  uint16_t txid = (uint16_t)(esp_random() & 0xffff);
  uint8_t q[64] = {0};
  q[0] = txid >> 8; q[1] = txid & 0xff;
  q[5] = 1; // QDCOUNT
  int p = 12;
  q[p++] = 32;
  char raw[16]; memset(raw, ' ', sizeof(raw)); raw[0] = '*'; raw[15] = 0;
  for (int i = 0; i < 16; i++) {
    uint8_t c = (uint8_t)raw[i];
    q[p++] = 'A' + ((c >> 4) & 0x0f);
    q[p++] = 'A' + (c & 0x0f);
  }
  q[p++] = 0;
  q[p++] = 0; q[p++] = 0x21; // NBSTAT
  q[p++] = 0; q[p++] = 1;    // IN
  u.beginPacket(ip, 137); u.write(q, p); u.endPacket();

  unsigned long deadline = millis() + 110;
  uint8_t r[600];
  while ((long)(deadline - millis()) > 0) {
    int n = u.parsePacket();
    if (n > 0) {
      n = min(n, (int)sizeof(r));
      int got = u.read(r, n);
      if (got < 20 || r[0] != (txid >> 8) || r[1] != (txid & 0xff)) continue;
      int qd = (r[4] << 8) | r[5];
      int an = (r[6] << 8) | r[7];
      int x = 12;
      for (int i = 0; i < qd && x < got; i++) { x = skipDnsName(r, got, x); x += 4; }
      for (int a = 0; a < an && x + 10 <= got; a++) {
        x = skipDnsName(r, got, x);
        if (x + 10 > got) break;
        uint16_t type = (r[x] << 8) | r[x+1];
        uint16_t rdlen = (r[x+8] << 8) | r[x+9];
        x += 10;
        if (x + rdlen > got) break;
        if (type == 0x21 && rdlen > 1) {
          int cnt = r[x];
          int e = x + 1;
          String fallback;
          for (int i = 0; i < cnt && e + 18 <= x + rdlen; i++, e += 18) {
            String nm;
            for (int k = 0; k < 15; k++) nm += (char)r[e+k];
            nm.trim();
            uint8_t suffix = r[e+15];
            uint16_t flags = (r[e+16] << 8) | r[e+17];
            bool group = flags & 0x8000;
            if (!group && nm.length() && nm != "__MSBROWSE__") {
              if (suffix == 0x00 || suffix == 0x20) { u.stop(); return nm; }
              if (!fallback.length()) fallback = nm;
            }
          }
          if (fallback.length()) { u.stop(); return fallback; }
        }
        x += rdlen;
      }
    }
    delay(4);
  }
  u.stop();
  return "";
}

String genericDetectedName(const FoundDevice &f) {
  if (f.hostname.length()) return f.hostname;
  if (f.ip == WiFi.gatewayIP().toString()) return "ZTE F670Y";
  if (f.mac.length() >= 2) {
    int b0 = strtol(f.mac.substring(0, 2).c_str(), nullptr, 16);
    if (b0 & 0x02) return "Thiết bị dùng MAC riêng tư";
  }
  return "Thiết bị không công bố tên";
}

void resolveFoundNames() {
  for (int i = 0; i < foundCount; i++) {
    found[i].hostname = "";
    found[i].nameSource = "";
    int idx = findDeviceByMac(found[i].mac);
    if (idx < 0) idx = findDeviceByIp(found[i].ip);
    if (idx >= 0 && devices[idx].name.length()) {
      found[i].hostname = devices[idx].name;
      found[i].nameSource = "saved";
      continue;
    }
    if (found[i].ip == WiFi.gatewayIP().toString()) {
      found[i].hostname = "ZTE F670Y";
      found[i].nameSource = "gateway";
      continue;
    }
    IPAddress target;
    if (!target.fromString(found[i].ip)) continue;
    String h = resolveMdnsReverse(target);
    if (h.length()) { found[i].hostname = h; found[i].nameSource = "mDNS"; continue; }
    h = resolveNetbiosName(target);
    if (h.length()) { found[i].hostname = h; found[i].nameSource = "NetBIOS"; continue; }
  }
}

void addFound(const String &ip, const String &mac) {
  String m = normalizeMac(mac);
  for (int i = 0; i < foundCount; i++) {
    if ((m.length() && found[i].mac == m) || found[i].ip == ip) {
      found[i].ip = ip; found[i].mac = m; found[i].seenMs = millis();
      return;
    }
  }
  if (foundCount < 48) {
    found[foundCount].ip = ip;
    found[foundCount].mac = m;
    found[foundCount].hostname = "";
    found[foundCount].nameSource = "";
    found[foundCount].seenMs = millis();
    foundCount++;
  }
}

void updateRegisteredFromFound() {
  unsigned long now = millis();
  for (int i = 0; i < deviceCount; i++) devices[i].online = false;
  for (int j = 0; j < foundCount; j++) {
    int idx = findDeviceByMac(found[j].mac);
    if (idx < 0) idx = findDeviceByIp(found[j].ip);
    if (idx >= 0) {
      devices[idx].online = true;
      devices[idx].lastSeenMs = now;
      if (found[j].mac.length()) devices[idx].mac = found[j].mac;
      if (found[j].ip.length()) devices[idx].ip = found[j].ip;
    }
  }
  for (int i = 0; i < deviceCount; i++) {
    if (devices[i].agentSeen && (now - devices[i].lastAgentMs < 45000UL)) {
      devices[i].online = true;
    }
  }
}

void scanLan() {
  if (WiFi.status() != WL_CONNECTED || scanRunning) return;
  scanRunning = true;
  foundCount = 0;

  IPAddress local = WiFi.localIP();
  IPAddress mask = WiFi.subnetMask();
  // Optimized for user's 192.168.1.0/24. For non-/24, scan local /24 only.
  if (!(mask[0] == 255 && mask[1] == 255 && mask[2] == 255)) {
    scanRunning = false;
    return;
  }

  arpUdp.begin(45678);
  uint8_t payload = 0x50;
  // Scan in small batches. lwIP keeps a small ARP cache; probing all 254 hosts
  // first can evict early entries before we read them. Eight hosts per batch
  // gives each device time to answer while keeping responses in the cache.
  const int batchSize = 8;
  for (int base = 1; base <= 254; base += batchSize) {
    int last = min(254, base + batchSize - 1);
    for (int host = base; host <= last; host++) {
      IPAddress target(local[0], local[1], local[2], host);
      if (target == local) continue;
      arpUdp.beginPacket(target, 9);
      arpUdp.write(&payload, 1);
      arpUdp.endPacket();
      delay(2);
    }

    delay(55);
    if (netif_default) {
      for (int host = base; host <= last; host++) {
        IPAddress target(local[0], local[1], local[2], host);
        if (target == local) continue;
        ip4_addr_t addr;
        IP4_ADDR(&addr, target[0], target[1], target[2], target[3]);
        struct eth_addr *eth = nullptr;
        const ip4_addr_t *ipret = nullptr;
        if (etharp_find_addr(netif_default, &addr, &eth, &ipret) >= 0 && eth) {
          String mac = macToString(eth);
          if (mac != "ff:ff:ff:ff:ff:ff" && mac != "00:00:00:00:00:00") addFound(target.toString(), mac);
        }
      }
    }
  }
  arpUdp.stop();

  // Ensure router itself appears if cached
  IPAddress gw = WiFi.gatewayIP();
  if (gw[0] != 0 && netif_default) {
    ip4_addr_t addr; IP4_ADDR(&addr, gw[0], gw[1], gw[2], gw[3]);
    struct eth_addr *eth = nullptr; const ip4_addr_t *ipret = nullptr;
    if (etharp_find_addr(netif_default, &addr, &eth, &ipret) >= 0 && eth) addFound(gw.toString(), macToString(eth));
  }

  resolveFoundNames();
  updateRegisteredFromFound();
  lastAutoScan = millis();
  scanRunning = false;
}

// -------------------- Monitoring helpers --------------------
void pushDailyHistory(Device &d, const String &dayKey) {
  for (int h = 6; h > 0; h--) { d.histMin[h] = d.histMin[h - 1]; d.histDay[h] = d.histDay[h - 1]; }
  d.histMin[0] = d.usedMin;
  d.histDay[0] = dayKey;
  d.usedMin = 0;
  d.bonusMin = 0;
  d.currentSessionMin = 0;
  d.longestSessionMin = 0;
  d.sessionsToday = 0;
  d.activeNow = false;
  d.currentApp = "";
  d.currentPackage = "";
}

void clearDailyAppUsage() {
  appUsageCount = 0;
  prefs.remove("appUsage");
}

void countAppMinute(const Device &d) {
  if (!d.agentActive || !d.currentPackage.length()) return;
  for (int i = 0; i < appUsageCount; i++) {
    if (appUsage[i].deviceId == d.id && appUsage[i].packageName == d.currentPackage) {
      appUsage[i].minutes++;
      if (d.currentApp.length()) appUsage[i].label = d.currentApp;
      return;
    }
  }
  if (appUsageCount < 32) {
    AppUsage &u = appUsage[appUsageCount++];
    u.deviceId = d.id; u.packageName = d.currentPackage;
    u.label = d.currentApp.length() ? d.currentApp : d.currentPackage;
    u.minutes = 1;
  }
}

// -------------------- Daily usage --------------------
void tickUsage() {
  if (millis() - lastMinuteTick < 60000UL) return;
  lastMinuteTick = millis();

  String day = currentDayKey();
  if (day.length() && day != lastDayKey) {
    String previous = lastDayKey.length() ? lastDayKey : day;
    for (int i = 0; i < deviceCount; i++) pushDailyHistory(devices[i], previous);
    clearDailyAppUsage();
    lastDayKey = day;
    saveDevices();
  } else if (day.length() && !lastDayKey.length()) {
    lastDayKey = day;
  }

  unsigned long now = millis();
  for (int i = 0; i < deviceCount; i++) {
    Device &d = devices[i];
    bool agentFresh = d.agentSeen && (now - d.lastAgentMs < 45000UL);
    bool active = agentFresh ? d.agentActive : d.online; // iPad/other: network-presence estimate

    if (active && !d.activeNow) {
      d.activeNow = true;
      d.currentSessionMin = 0;
      d.sessionsToday++;
    } else if (!active && d.activeNow) {
      d.activeNow = false;
      d.currentSessionMin = 0;
    }

    if (active && !effectiveLocked(d)) {
      d.usedMin++;
      d.currentSessionMin++;
      if (d.currentSessionMin > d.longestSessionMin) d.longestSessionMin = d.currentSessionMin;
      if (agentFresh) countAppMinute(d);
    }
  }

  if (millis() - lastUsageSave > 600000UL) { saveDevices(); lastUsageSave = millis(); }
}

// -------------------- JSON/API helpers --------------------
void sendJson(DynamicJsonDocument &doc, int code = 200) {
  String s; serializeJson(doc, s);
  server.send(code, "application/json; charset=utf-8", s);
}

bool parseBody(DynamicJsonDocument &doc) {
  return deserializeJson(doc, server.arg("plain")) == DeserializationError::Ok;
}

void apiStatus() {
  DynamicJsonDocument doc(2048);
  doc["ok"] = true;
  doc["firmwareVersion"] = FW_VERSION;
  doc["version"] = FW_VERSION;
  doc["setupMode"] = setupMode;
  doc["wifi"] = WiFi.status() == WL_CONNECTED;
  doc["ssid"] = WiFi.SSID();
  doc["ip"] = WiFi.localIP().toString();
  doc["gateway"] = WiFi.gatewayIP().toString();
  doc["rssi"] = WiFi.RSSI();
  doc["host"] = String(HOSTNAME) + ".local";
  doc["uptimeSec"] = millis() / 1000UL;
  doc["scanRunning"] = scanRunning;
  doc["timeKnown"] = timeKnown();
  doc["routerModel"] = "ZTE F670Y";
  doc["routerEnforcement"] = false;
  sendJson(doc);
}

void apiDevices() {
  DynamicJsonDocument doc(32768);
  JsonArray a = doc.createNestedArray("devices");
  for (int i = 0; i < deviceCount; i++) {
    Device &d = devices[i];
    JsonObject o = a.add<JsonObject>();
    o["id"] = d.id; o["name"] = d.name; o["group"] = d.group; o["groupLabel"] = groupLabel(d.group);
    o["kind"] = d.kind; o["ip"] = d.ip; o["mac"] = d.mac; o["online"] = d.online;
    o["manualBlocked"] = d.manualBlocked; o["locked"] = effectiveLocked(d);
    o["limitMin"] = d.limitMin; o["bonusMin"] = d.bonusMin; o["usedMin"] = d.usedMin;
    o["remainingMin"] = remainingMin(d); o["from"] = d.from; o["to"] = d.to;
    bool agentFresh = d.agentSeen && (millis() - d.lastAgentMs < 45000UL);
    o["agent"] = agentFresh;
    o["agentActive"] = d.agentActive;
    o["activeNow"] = agentFresh ? d.agentActive : d.online;
    o["activitySource"] = agentFresh ? "agent" : "network";
    o["currentSessionMin"] = d.currentSessionMin; o["longestSessionMin"] = d.longestSessionMin;
    o["sessionsToday"] = d.sessionsToday; o["currentApp"] = d.currentApp; o["currentPackage"] = d.currentPackage;
    JsonArray hm = o.createNestedArray("histMin"); JsonArray hd = o.createNestedArray("histDay");
    for (int h = 0; h < 7; h++) { hm.add(d.histMin[h]); hd.add(d.histDay[h]); }
    JsonArray apps = o.createNestedArray("apps");
    for (int u = 0; u < appUsageCount; u++) if (appUsage[u].deviceId == d.id) {
      JsonObject au = apps.add<JsonObject>(); au["label"] = appUsage[u].label; au["package"] = appUsage[u].packageName; au["minutes"] = appUsage[u].minutes;
    }
  }
  sendJson(doc);
}

void apiFound() {
  DynamicJsonDocument doc(12288);
  JsonArray a = doc.createNestedArray("found");
  for (int i = 0; i < foundCount; i++) {
    bool registered = findDeviceByMac(found[i].mac) >= 0 || findDeviceByIp(found[i].ip) >= 0;
    JsonObject o = a.add<JsonObject>();
    o["ip"] = found[i].ip; o["mac"] = found[i].mac; o["registered"] = registered;
    o["hostname"] = found[i].hostname; o["displayName"] = genericDetectedName(found[i]); o["nameSource"] = found[i].nameSource;
    o["isGateway"] = found[i].ip == WiFi.gatewayIP().toString();
  }
  sendJson(doc);
}

void apiRegister() {
  DynamicJsonDocument j(2048), r(512);
  if (!parseBody(j) || deviceCount >= 32) { r["ok"] = false; r["error"] = "invalid"; sendJson(r, 400); return; }
  String mac = normalizeMac(String((const char*)(j["mac"] | "")));
  String ip = String((const char*)(j["ip"] | ""));
  int idx = findDeviceByMac(mac); if (idx < 0) idx = findDeviceByIp(ip);
  if (idx < 0) idx = deviceCount++;
  Device &d = devices[idx];
  if (!d.id.length()) d.id = makeId(mac, ip);
  d.name = String((const char*)(j["name"] | "Thiết bị"));
  d.group = String((const char*)(j["group"] | "Khach"));
  d.kind = String((const char*)(j["kind"] | "Other"));
  d.ip = ip; d.mac = mac;
  if (!d.from.length()) d.from = "06:30"; if (!d.to.length()) d.to = "20:30";
  if (d.limitMin <= 0) d.limitMin = 120;
  saveDevices();
  r["ok"] = true; r["id"] = d.id; sendJson(r);
}

void apiPolicy() {
  DynamicJsonDocument j(2048), r(512);
  if (!parseBody(j)) { r["ok"] = false; sendJson(r, 400); return; }
  int idx = findDeviceById(String((const char*)(j["id"] | "")));
  if (idx < 0) { r["ok"] = false; r["error"] = "not_found"; sendJson(r, 404); return; }
  Device &d = devices[idx];
  if (!j["name"].isNull()) d.name = j["name"].as<String>();
  if (!j["group"].isNull()) d.group = j["group"].as<String>();
  if (!j["kind"].isNull()) d.kind = j["kind"].as<String>();
  if (!j["limitMin"].isNull()) d.limitMin = max(0, j["limitMin"].as<int>());
  if (!j["from"].isNull()) d.from = j["from"].as<String>();
  if (!j["to"].isNull()) d.to = j["to"].as<String>();
  saveDevices(); r["ok"] = true; sendJson(r);
}

void apiAction() {
  DynamicJsonDocument j(1024), r(256);
  if (!parseBody(j)) { r["ok"] = false; sendJson(r, 400); return; }
  int idx = findDeviceById(String((const char*)(j["id"] | "")));
  if (idx < 0) { r["ok"] = false; sendJson(r, 404); return; }
  Device &d = devices[idx];
  String action = String((const char*)(j["action"] | ""));
  if (action == "lock") d.manualBlocked = true;
  else if (action == "unlock") d.manualBlocked = false;
  else if (action == "bonus") d.bonusMin += max(0, j["minutes"] | 30);
  else if (action == "resetUsage") { d.usedMin = 0; d.bonusMin = 0; }
  saveDevices(); r["ok"] = true; r["locked"] = effectiveLocked(d); sendJson(r);
}

void apiGroupAction() {
  DynamicJsonDocument j(1024), r(256);
  if (!parseBody(j)) { r["ok"] = false; sendJson(r, 400); return; }
  String group = String((const char*)(j["group"] | "Be"));
  String action = String((const char*)(j["action"] | ""));
  for (int i = 0; i < deviceCount; i++) if (devices[i].group == group) {
    if (action == "lock") devices[i].manualBlocked = true;
    else if (action == "unlock") devices[i].manualBlocked = false;
    else if (action == "bonus") devices[i].bonusMin += max(0, j["minutes"] | 30);
  }
  saveDevices(); r["ok"] = true; sendJson(r);
}

void apiDelete() {
  DynamicJsonDocument j(512), r(256);
  if (!parseBody(j)) { r["ok"] = false; sendJson(r, 400); return; }
  int idx = findDeviceById(String((const char*)(j["id"] | "")));
  if (idx < 0) { r["ok"] = false; sendJson(r, 404); return; }
  for (int i = idx; i < deviceCount - 1; i++) devices[i] = devices[i + 1];
  deviceCount--; saveDevices(); r["ok"] = true; sendJson(r);
}

void apiAgentHeartbeat() {
  DynamicJsonDocument j(1024), r(512);
  if (!parseBody(j)) { r["ok"] = false; sendJson(r, 400); return; }
  String id = String((const char*)(j["id"] | ""));
  String mac = normalizeMac(String((const char*)(j["mac"] | "")));
  int idx = findDeviceById(id); if (idx < 0) idx = findDeviceByMac(mac);
  if (idx < 0) { r["ok"] = false; r["error"] = "not_registered"; sendJson(r, 404); return; }
  Device &d = devices[idx];
  d.agentSeen = true; d.lastAgentMs = millis(); d.online = true;
  d.agentActive = j["active"] | false;
  if (!j["ip"].isNull()) d.ip = j["ip"].as<String>();
  if (!j["appLabel"].isNull()) d.currentApp = j["appLabel"].as<String>();
  if (!j["appPackage"].isNull()) d.currentPackage = j["appPackage"].as<String>();
  if (!d.agentActive) { d.currentApp = ""; d.currentPackage = ""; }
  r["ok"] = true; r["locked"] = effectiveLocked(d); r["remainingMin"] = remainingMin(d);
  sendJson(r);
}

void apiAgentPolicy() {
  String id = server.arg("id");
  int idx = findDeviceById(id);
  DynamicJsonDocument r(512);
  if (idx < 0) { r["ok"] = false; sendJson(r, 404); return; }
  Device &d = devices[idx];
  r["ok"] = true; r["locked"] = effectiveLocked(d); r["remainingMin"] = remainingMin(d);
  r["from"] = d.from; r["to"] = d.to; r["limitMin"] = d.limitMin; r["bonusMin"] = d.bonusMin;
  sendJson(r);
}

void apiChildSummary() {
  DynamicJsonDocument r(4096);
  r["ok"] = true;
  int used = 0, online = 0, active = 0, count = 0;
  for (int i = 0; i < deviceCount; i++) if (devices[i].group == "Be") {
    count++; used += devices[i].usedMin; if (devices[i].online) online++;
    bool agentFresh = devices[i].agentSeen && (millis() - devices[i].lastAgentMs < 45000UL);
    if (agentFresh ? devices[i].agentActive : devices[i].online) active++;
  }
  r["deviceCount"] = count; r["onlineCount"] = online; r["activeCount"] = active; r["usedMin"] = used;
  sendJson(r);
}


// -------------------- Firmware update check --------------------
int versionPart(const String &v, int index) {
  int start = 0;
  for (int i = 0; i < index; i++) {
    int p = v.indexOf('.', start);
    if (p < 0) return 0;
    start = p + 1;
  }
  int end = v.indexOf('.', start);
  String part = end < 0 ? v.substring(start) : v.substring(start, end);
  int dash = part.indexOf('-');
  if (dash >= 0) part = part.substring(0, dash);
  return part.toInt();
}

bool isVersionNewer(const String &latest, const String &current) {
  for (int i = 0; i < 3; i++) {
    int a = versionPart(latest, i), b = versionPart(current, i);
    if (a > b) return true;
    if (a < b) return false;
  }
  return false;
}

void apiUpdateCheck() {
  DynamicJsonDocument out(2048);
  out["ok"] = false;
  out["currentVersion"] = FW_VERSION;
  out["releaseUrl"] = RELEASES_URL;
  if (WiFi.status() != WL_CONNECTED) {
    out["error"] = "ESP32 chưa kết nối Internet";
    sendJson(out, 503);
    return;
  }

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setConnectTimeout(7000);
  http.setTimeout(7000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  if (!http.begin(client, UPDATE_MANIFEST_URL)) {
    out["error"] = "Không mở được máy chủ cập nhật";
    sendJson(out, 502);
    return;
  }
  int code = http.GET();
  if (code != HTTP_CODE_OK) {
    out["error"] = String("GitHub HTTP ") + code;
    http.end();
    sendJson(out, 502);
    return;
  }
  String payload = http.getString();
  http.end();
  DynamicJsonDocument manifest(2048);
  DeserializationError err = deserializeJson(manifest, payload);
  if (err) {
    out["error"] = "Manifest cập nhật không hợp lệ";
    sendJson(out, 502);
    return;
  }
  String latest = String((const char*)(manifest["version"] | ""));
  String notes = String((const char*)(manifest["notes"] | ""));
  String releaseUrl = String((const char*)(manifest["release_url"] | RELEASES_URL));
  String binUrl = String((const char*)(manifest["bin_url"] | ""));
  out["ok"] = true;
  out["latestVersion"] = latest;
  out["updateAvailable"] = latest.length() && isVersionNewer(latest, FW_VERSION);
  out["notes"] = notes;
  out["releaseUrl"] = releaseUrl;
  out["binUrl"] = binUrl;
  sendJson(out);
}

// Web UI moved to web_ui.h to avoid Arduino sketch preprocessor parsing JavaScript.
#include "web_ui.h"


// -------------------- Wi-Fi setup / scan --------------------
// Keep the ESP-IDF regulatory configuration unchanged.  The default
// world-safe configuration can still discover broadcast APs on ch.12/13 by
// passive scanning, while avoiding a hard-coded regulatory domain.
void prepareWifiRadioForScan() {
  WiFi.setSleep(false);
}

String wifiErrName(esp_err_t err) {
  if (err == ESP_OK) return "ok";
  if (err == ESP_ERR_WIFI_NOT_INIT) return "wifi_not_init";
  if (err == ESP_ERR_WIFI_NOT_STARTED) return "wifi_not_started";
  if (err == ESP_ERR_WIFI_STATE) return "wifi_busy";
  if (err == ESP_ERR_WIFI_TIMEOUT) return "wifi_timeout";
  return String("esp_err_") + String((int)err);
}

// Low-level IDF scan. It gives us the exact ESP-IDF error and lets us
// explicitly cancel stale scan/connection state before a new scan. Passive
// scanning is used deliberately so broadcast APs on channels 12/13 can still
// be discovered without forcing a regulatory domain.
esp_err_t scanWifiIdf(wifi_ap_record_t *records, uint16_t capacity, uint16_t &count) {
  count = 0;
  if (!records || capacity == 0) return ESP_ERR_INVALID_ARG;

  // In setup mode the SoftAP must remain alive for the phone, while the STA
  // side is idle and available for scanning. When already connected to the
  // home Wi-Fi (/wifi page), do NOT disconnect the STA or the HTTP request
  // itself would be lost.
  if (setupMode) WiFi.mode(WIFI_AP_STA);
  else WiFi.mode(WIFI_STA);
  prepareWifiRadioForScan();

  // Cancel an old scan. Only cancel STA association in setup mode, where the
  // station is intentionally not connected to the home router.
  esp_wifi_scan_stop();
  if (setupMode) esp_wifi_disconnect();
  WiFi.scanDelete();
  delay(120);

  wifi_scan_config_t cfg = {};
  cfg.ssid = nullptr;
  cfg.bssid = nullptr;
  cfg.channel = 0;                 // all allowed channels
  cfg.show_hidden = false;          // hidden SSID is handled by manual entry
  cfg.scan_type = WIFI_SCAN_TYPE_PASSIVE;
  cfg.scan_time.passive = 300;        // enough time to catch normal beacons

  esp_err_t err = esp_wifi_scan_start(&cfg, true); // blocking scan
  if (err != ESP_OK) {
    delay(100);
    // One clean retry for transient ESP_ERR_WIFI_STATE / timeout.
    esp_wifi_scan_stop();
    if (setupMode) esp_wifi_disconnect();
    delay(180);
    err = esp_wifi_scan_start(&cfg, true);
  }
  if (err != ESP_OK) return err;

  uint16_t total = 0;
  err = esp_wifi_scan_get_ap_num(&total);
  if (err != ESP_OK) { esp_wifi_clear_ap_list(); return err; }

  uint16_t n = total < capacity ? total : capacity;
  if (n == 0) { esp_wifi_clear_ap_list(); count = 0; return ESP_OK; }
  err = esp_wifi_scan_get_ap_records(&n, records);
  if (err != ESP_OK) { esp_wifi_clear_ap_list(); return err; }
  count = n;
  return ESP_OK;
}

void apiWifiScan() {
  static wifi_ap_record_t records[40];
  uint16_t count = 0;
  esp_err_t err = scanWifiIdf(records, 40, count);

  DynamicJsonDocument doc(16384);
  doc["ok"] = err == ESP_OK;
  doc["count"] = err == ESP_OK ? count : 0;
  doc["errorCode"] = (int)err;
  doc["error"] = wifiErrName(err);
  JsonArray a = doc.createNestedArray("networks");

  if (err == ESP_OK) {
    for (uint16_t i = 0; i < count; i++) {
      String ssid = String((const char*)records[i].ssid);
      if (!ssid.length()) continue; // hidden SSID can be entered manually

      // Deduplicate multiple BSSIDs broadcasting the same SSID; keep strongest.
      int existing = -1;
      for (size_t k = 0; k < a.size(); k++) {
        JsonObject x = a[k];
        if (String((const char*)(x["ssid"] | "")) == ssid) { existing = (int)k; break; }
      }
      if (existing >= 0) {
        JsonObject x = a[existing];
        if ((int)records[i].rssi > (int)(x["rssi"] | -127)) {
          x["rssi"] = (int)records[i].rssi;
          x["channel"] = (int)records[i].primary;
          x["secure"] = records[i].authmode != WIFI_AUTH_OPEN;
        }
        continue;
      }

      JsonObject o = a.add<JsonObject>();
      o["ssid"] = ssid;
      o["rssi"] = (int)records[i].rssi;
      o["channel"] = (int)records[i].primary;
      o["secure"] = records[i].authmode != WIFI_AUTH_OPEN;
    }
  }
  sendJson(doc);
}

// -------------------- HTTP routes --------------------
void setupCommonRoutes() {
  server.on("/api/status", HTTP_GET, apiStatus);
  server.on("/api/devices", HTTP_GET, apiDevices);
  server.on("/api/child/summary", HTTP_GET, apiChildSummary);
  server.on("/api/found", HTTP_GET, apiFound);
  server.on("/api/scan", HTTP_POST, [](){ scanLan(); DynamicJsonDocument r(128); r["ok"] = true; r["count"] = foundCount; sendJson(r); });
  server.on("/api/device/register", HTTP_POST, apiRegister);
  server.on("/api/device/policy", HTTP_POST, apiPolicy);
  server.on("/api/device/action", HTTP_POST, apiAction);
  server.on("/api/group/action", HTTP_POST, apiGroupAction);
  server.on("/api/device/delete", HTTP_POST, apiDelete);
  server.on("/api/agent/heartbeat", HTTP_POST, apiAgentHeartbeat);
  server.on("/api/agent/policy", HTTP_GET, apiAgentPolicy);
  server.on("/api/update/check", HTTP_GET, apiUpdateCheck);
  server.on("/api/system/restart", HTTP_POST, [](){ DynamicJsonDocument r(128); r["ok"] = true; sendJson(r); delay(400); ESP.restart(); });
  server.on("/api/system/resetwifi", HTTP_POST, [](){
    prefs.remove("ssid"); prefs.remove("pass"); prefs.putBool("customWifi", false); prefs.putBool("forceSetup", true);
    DynamicJsonDocument r(128); r["ok"] = true; sendJson(r); delay(500); ESP.restart();
  });
}

void setupSetupRoutes() {
  server.on("/", HTTP_GET, [](){ server.send_P(200, "text/html; charset=utf-8", SETUP_HTML); });
  server.on("/generate_204", HTTP_GET, [](){ server.sendHeader("Location", "http://192.168.4.1/", true); server.send(302, "text/plain", ""); });
  server.on("/hotspot-detect.html", HTTP_GET, [](){ server.sendHeader("Location", "http://192.168.4.1/", true); server.send(302, "text/plain", ""); });
  server.on("/api/setup/scan", HTTP_GET, apiWifiScan);
  server.on("/api/setup/connect", HTTP_POST, [](){
    DynamicJsonDocument j(1024), r(256);
    if (!parseBody(j)) { r["ok"] = false; r["error"] = "Dữ liệu không hợp lệ"; sendJson(r, 400); return; }
    String ssid = String((const char*)(j["ssid"] | ""));
    String pass = String((const char*)(j["pass"] | ""));
    if (!ssid.length()) { r["ok"] = false; r["error"] = "Chưa chọn Wi‑Fi"; sendJson(r, 400); return; }
    prefs.putString("ssid", ssid); prefs.putString("pass", pass); prefs.putBool("customWifi", true); prefs.putBool("forceSetup", false);
    r["ok"] = true; sendJson(r); delay(700); ESP.restart();
  });
  server.onNotFound([](){ server.sendHeader("Location", "http://192.168.4.1/", true); server.send(302, "text/plain", ""); });
}

void setupAppRoutes() {
  server.on("/", HTTP_GET, [](){ server.send_P(200, "text/html; charset=utf-8", APP_HTML); });
  server.on("/wifi", HTTP_GET, [](){ server.send_P(200, "text/html; charset=utf-8", SETUP_HTML); });
  setupCommonRoutes();
  server.on("/api/setup/scan", HTTP_GET, apiWifiScan);
  server.on("/api/setup/connect", HTTP_POST, [](){
    DynamicJsonDocument j(1024), r(256);
    if (!parseBody(j)) { r["ok"] = false; r["error"] = "Dữ liệu không hợp lệ"; sendJson(r, 400); return; }
    String ssid = String((const char*)(j["ssid"] | ""));
    String pass = String((const char*)(j["pass"] | ""));
    if (!ssid.length()) { r["ok"] = false; r["error"] = "Chưa chọn Wi‑Fi"; sendJson(r, 400); return; }
    prefs.putString("ssid", ssid); prefs.putString("pass", pass); prefs.putBool("customWifi", true); prefs.putBool("forceSetup", false);
    r["ok"] = true; sendJson(r); delay(700); ESP.restart();
  });
  server.onNotFound([](){ server.send(404, "application/json", "{\"ok\":false,\"error\":\"not_found\"}"); });
}

void startSetupPortal() {
  setupMode = true;

  // Stop any unfinished STA connection attempt before enabling AP+STA.
  // Otherwise ESP32 can report WIFI_SCAN_FAILED on every setup-page scan.
  WiFi.disconnect(false, false);
  delay(250);
  WiFi.mode(WIFI_AP_STA);
  prepareWifiRadioForScan();
  WiFi.setSleep(false);
  WiFi.softAP(AP_SSID, AP_PASS);
  delay(100);
  dnsServer.start(53, "*", WiFi.softAPIP());
  setupSetupRoutes();
  server.begin();
  Serial.println();
  Serial.println("=== Parent Hub Setup ===");
  Serial.print("Wi-Fi: "); Serial.println(AP_SSID);
  Serial.print("Password: "); Serial.println(AP_PASS);
  Serial.print("Open: http://"); Serial.println(WiFi.softAPIP());
}

bool tryWifiCredentials(const String &ssid, const String &pass) {
  if (!ssid.length()) return false;
  WiFi.mode(WIFI_STA);
  prepareWifiRadioForScan();
  WiFi.disconnect(false, false);
  delay(120);
  WiFi.setHostname(HOSTNAME);
  WiFi.begin(ssid.c_str(), pass.c_str());
  Serial.print("Connecting to "); Serial.println(ssid);
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 18000UL) {
    delay(300); Serial.print('.');
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) return true;

  // A timed-out WiFi.begin() can leave the STA radio in CONNECTING state.
  // Explicitly cancel it so the fallback setup portal can scan normally.
  WiFi.disconnect(false, false);
  delay(250);
  return false;
}

bool connectHomeWifi() {
  // Wi-Fi selected by the user is the single primary connection.
  // Credentials live in NVS, so changing firmware does not normally lose them.
  if (prefs.getBool("forceSetup", false)) return false;

  String savedSsid = prefs.getString("ssid", "");
  String savedPass = prefs.getString("pass", "");
  if (!savedSsid.length()) return false;

  if (tryWifiCredentials(savedSsid, savedPass)) {
    prefs.putBool("customWifi", true);
    prefs.putBool("forceSetup", false);
    return true;
  }

  // Do not silently switch to another hard-coded network. If the selected
  // network cannot be reached, start ParentHub-Setup so the owner can choose
  // a new Wi-Fi from the web configuration page.
  return false;
}

void startApp() {
  setupMode = false;
  configTime(7 * 3600, 0, "pool.ntp.org", "time.google.com", "time.cloudflare.com");
  if (MDNS.begin(HOSTNAME)) MDNS.addService("http", "tcp", 80);
  setupAppRoutes();
  server.begin();
  Serial.println("=== Parent Hub Online ===");
  Serial.print("SSID: "); Serial.println(WiFi.SSID());
  Serial.print("IP: http://"); Serial.println(WiFi.localIP());
  Serial.println("mDNS: http://parenthub.local");
  delay(500);
  scanLan();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  prefs.begin("parenthub", false);
  loadDevices();
  if (connectHomeWifi()) startApp(); else startSetupPortal();
}

void loop() {
  server.handleClient();
  if (setupMode) {
    dnsServer.processNextRequest();
    delay(2);
    return;
  }

  // Reconnect Wi-Fi if temporarily lost
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lostSince = 0;
    if (!lostSince) lostSince = millis();
    WiFi.reconnect();
    if (millis() - lostSince > 60000UL) { ESP.restart(); }
  }

  tickUsage();
  if (!scanRunning && millis() - lastAutoScan > 60000UL) scanLan();
  delay(2);
}
