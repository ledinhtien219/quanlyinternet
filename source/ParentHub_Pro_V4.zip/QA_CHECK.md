ParentHub Stable V3.0 - QA checklist

Checked before packaging:
- Arduino sketch name matches folder name.
- web_ui.h included from sketch and both raw-string HTML blocks close correctly.
- JavaScript syntax checked with Node.js for Setup UI and Main UI.
- No JavaScript `async function` remains in the .ino file (avoids Arduino preprocessor issue).
- No optional-chaining / nullish-coalescing in UI (better captive WebView compatibility).
- Wi-Fi credentials are not hard-coded.
- Captive setup, manual SSID entry, /wifi page, Wi-Fi scan diagnostics are present.
- Wi-Fi scan uses ESP-IDF scan API with explicit stale-state cleanup and retry.
- LAN scan uses small ARP batches to reduce missed devices from ARP-cache eviction.
- Parental-monitor API, Android Box Agent endpoints, device policy storage are present.

Hardware-dependent items that still require validation on the actual board/router:
- RF scan result on the local Wi-Fi environment.
- ZTE F670Y enforcement (not enabled in this Hub firmware yet).
- Android Box per-app usage requires the Agent APK.
