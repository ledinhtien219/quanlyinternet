ANDROID BOX AGENT API - Parent Hub V2
=====================================

Heartbeat (khoảng 10-20 giây/lần):
POST http://<IP_PARENT_HUB>/api/agent/heartbeat
Content-Type: application/json

{
  "id": "b859ce7eedbe",
  "mac": "b8:59:ce:7e:ed:be",
  "ip": "192.168.1.14",
  "active": true,
  "appLabel": "YouTube",
  "appPackage": "com.google.android.youtube.tv"
}

Response:
{
  "ok": true,
  "locked": false,
  "remainingMin": 84
}

Read policy:
GET http://<IP_PARENT_HUB>/api/agent/policy?id=b859ce7eedbe

Agent nên:
- active=true khi người dùng đang thực sự sử dụng Box / màn hình hoạt động.
- Gửi appLabel + appPackage của foreground app khi có quyền Usage Access.
- Khi locked=true: đưa màn hình khóa lên foreground và chặn quay lại nội dung
  theo mức quyền Android TV cho phép.
- Không cần gửi appLabel/appPackage khi active=false.
